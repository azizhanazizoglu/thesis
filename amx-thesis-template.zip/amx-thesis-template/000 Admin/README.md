`000 Admin` put all administrative stuff here, like registration forms, declarations etc.
