`031 Expose` here is your expose presentation, i.e. objectives, detailed task description, planned research methods and project planning
