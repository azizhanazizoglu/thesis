`100 Design and models` this folder is for models or CAD data
