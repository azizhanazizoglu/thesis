`020 Meetings` store meeting protocols here

Naming scheme: `YYYY-MM-DD_Meeting_<meeting id/description>.md`
