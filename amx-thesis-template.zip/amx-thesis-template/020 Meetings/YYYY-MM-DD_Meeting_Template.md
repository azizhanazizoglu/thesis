# Meeting <Thesis title>
YYYY-MM-DD, HH:MM, <Location>

## Attendees
* R. Kalman
* J. von Neumann
* A. Lyapunov
* C. Shannon

## Agenda
* 
* 
* 

## To-do list
* 
* 
* 
