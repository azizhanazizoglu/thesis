`900 Report` the LaTeX project is in this folder

You can compile and view the document by running the following batch files:
* `compileQuick.bat` : compiles the document and opens it
* `compile.bat` : compiles the document, runs BibTeX, compiles once again and opens the document
* `compileFinal.bat` : compiles and runs BibTeX several times (6 and 2 times respectively) and opens the document
* `compileMpost.bat` : compiles and runs METAPOST and BibTeX. Use if you have METAPOST images (e.g. UML diagrams created with `MetaUML`)
* `clean.bat` : deletes all auxiliary and temporary files (recursively!); also deletes all pdf documents _in the current folder only_

Edit the `setup/metadata.tex` file to customise your name, thesis title, date etc.

Second-level structure:
* `images` store images and figures here
* `tikz` put your TikZ files in this folder
* `setup` here are the configuration files
* `chapters` here are the `*.tex` files of the report itself
* `auxfiles` auxiliary stuff is stored here
* `attachments` (optional) here are the attachments
* `sources` (optional) here are the sources of your listings
* `bibtex` put the BibTeX file here
