#Control action u effect on a_i[0] and a_i[1]
#Take the result then convert to rhs with the help of ca.Function
#For follower agent's velocity we will use Lb
 
A_i = ca.vertcat(controls, L_b);
a_i = phi_alpha + cons + A_i; #acceralation of all agents

v_N = []
for i in range(0,num_agents):
    v_N = ca.vertcat(v_N, states[int(n_states/num_agents*i+2):int(n_states/num_agents*i+4) ,0])

x_swarm_dot1 = ca.vertcat(v_N[0],
                          v_N[1],
                          a_i[0],
                          a_i[1])

x_swarm_dot2 = ca.vertcat(v_N[2],
                          v_N[3],
                          a_i[2],
                          a_i[3])

x_swarm_dot3 = ca.vertcat(v_N[4],
                          v_N[5],
                          a_i[4],
                          a_i[5])

x_swarm_dot4 = ca.vertcat(v_N[6],
                          v_N[7],
                          a_i[6],
                          a_i[7])

x_swarm_dot5 = ca.vertcat(v_N[8],
                          v_N[9],
                          a_i[8],
                          a_i[9])

x_swarm_dot = ca.vertcat(x_swarm_dot1, x_swarm_dot2, x_swarm_dot3, x_swarm_dot4, x_swarm_dot5)
f_swarm_dot = ca.Function("f_swarm_dot", [states,controls],[x_swarm_dot]) 