Q1_x = 7000
Q1_y = 7000 
Q2_x = 1
Q2_y = 1

#Q1 weighting matrix for leead postion and target position
Q1 = ca.diagcat(Q1_x, Q1_y, Q1_vx, Q1_vy)
#Q2 weighting matrix for leader postion and follower position
Q2= ca.diagcat(Q2_x, Q2_y)

# controls side weighting
R = ca.diagcat(R1, R2)

g = X[:, 0] - P[:n_states] #initial constraints for MPC

obj = 0
#X comes from MPC solver. MPC updates after every iteration k
#objective Function
for k in range (N):
    st_1p_1 = X[0:4,k]
    st_1p = X[0:2,k] #leader
    st_2p = X[4:6,k] #follower
    st_3p = X[8:10,k] #follower
    st_4p = X[12:14,k] #follower
    st_5p = X[16:18,k] #follower
    st_all = X[:,k] #all agent's states
    
    #Q1 = [3800,3800,1,1], weighting of vx and vy is 3800x small then positions. In the report assumed Q1 as [2x1] (only for positions)
    con = U[:,k]
    obj = obj \
        + (st_1p_1 - P[int(n_states* (k +1 )): int(n_states* (k +1) + n_states/num_agents)]).T @ Q1 @ (st_1p_1 - P[int(n_states* (k +1 )): int(n_states* (k +1) + n_states/num_agents)]) \
            + con.T @ R @ con \
              + ((st_1p - st_2p)**2).T @ Q2 @ ((st_1p - st_2p)**2) \
                 + ((st_1p - st_3p)**2).T @ Q2 @ ((st_1p - st_3p)**2)\
                     + ((st_1p - st_4p)**2).T @ Q2 @ ((st_1p - st_4p)**2)\
                         + ((st_1p - st_5p)**2).T @ Q2 @ ((st_1p - st_5p)**2)

    st_all_next = X[:,k+1] #MPC prediction  
    f_value = f_swarm_dot(st_all,con) #Olfati -Saber Model implemented in
    # this function. 
    st_next_real = st_all + (T * f_value) #Real value from Olfati-Saber
    g = ca.vertcat(g, st_all_next - st_next_real) #Equality constraint
            
#X and U global variables, they are symbolic 
#changing inside the main loop (simulation)


for k in range (N+1): #MPC coinstraints included st_next, thats why N+1
    #Obstackles Constraints
    g = ca.vertcat(g, ((rob_dim /2 + obs_dim/2+ 5) - (np.sqrt((X[0,k]-obs_x)**2 + (X[1,k]-obs_y)**2))))
    #First part of g, we put all MPC equlity constraints, second part we are putting obstackles 

for k in range (N+1): #MPC coinstraints included st_next, thats why N+1
    #Obstackle Constraints for agent 2
    g = ca.vertcat(g, ((rob_dim /2 + obs_dim/2 + 5) - (np.sqrt((X[4,k]-obs_x)**2 + (X[5,k]-obs_y)**2))))
    
for k in range (N+1): #MPC coinstraints included st_next, thats why N+1
    #Obstackle Constraints for agent 3
    g = ca.vertcat(g, ((rob_dim /2 + obs_dim/2 + 5) - (np.sqrt((X[8,k]-obs_x)**2 + (X[9,k]-obs_y)**2))))

for k in range (N+1): #MPC coinstraints included st_next, thats why N+1
    #Obstackle Constraints for agent 4
    g = ca.vertcat(g, ((rob_dim /2 + obs_dim/2 + 5) - (np.sqrt((X[12,k]-obs_x)**2 + (X[13,k]-obs_y)**2))))
    
for k in range (N+1): #MPC coinstraints included st_next, thats why N+1
    #Obstackle Constraints for agent 5
    g = ca.vertcat(g, ((rob_dim /2 + obs_dim/2 + 5) - (np.sqrt((X[16,k]-obs_x)**2 + (X[17,k]-obs_y)**2))))


#Repulsion and Attraction Region Constraints minDist< distance <r

for k in range (N+1): #MPC coinstraints included st_next, thats why N+1
    g = ca.vertcat(g, ((rob_dim /2 + rob_dim/2+minDist) - (np.sqrt((X[4,k]-X[0,k])**2 + (X[5,k]-X[1,k])**2))))
    
for k in range (N+1): 
    g = ca.vertcat(g, ((rob_dim /2 + rob_dim/2+minDist) - (np.sqrt((X[8,k]-X[0,k])**2 + (X[9,k]-X[1,k])**2))))
    
for k in range (N+1): 
    g = ca.vertcat(g, ((rob_dim /2 + rob_dim/2+minDist) - (np.sqrt((X[12,k]-X[0,k])**2 + (X[13,k]-X[1,k])**2))))
    
for k in range (N+1): 
    g = ca.vertcat(g, ((rob_dim /2 + rob_dim/2+minDist) - (np.sqrt((X[16,k]-X[0,k])**2 + (X[17,k]-X[1,k])**2)))) 
    
#--------- -agent2

for k in range (N+1): 
    g = ca.vertcat(g, ((rob_dim /2 + rob_dim/2+minDist) - (np.sqrt((X[8,k]-X[4,k])**2 + (X[9,k]-X[5,k])**2))))
    
for k in range (N+1): 
    g = ca.vertcat(g, ((rob_dim /2 + rob_dim/2+minDist) - (np.sqrt((X[12,k]-X[4,k])**2 + (X[13,k]-X[5,k])**2))))
    
for k in range (N+1): 
    g = ca.vertcat(g, ((rob_dim /2 + rob_dim/2+minDist) - (np.sqrt((X[16,k]-X[4,k])**2 + (X[17,k]-X[5,k])**2))))
    
#---------- -agent3

for k in range (N+1):
    g = ca.vertcat(g, ((rob_dim /2 + rob_dim/2+minDist) - (np.sqrt((X[12,k]-X[8,k])**2 + (X[13,k]-X[9,k])**2))))
    
for k in range (N+1):
    g = ca.vertcat(g, ((rob_dim /2 + rob_dim/2+minDist) - (np.sqrt((X[16,k]-X[8,k])**2 + (X[17,k]-X[9,k])**2)))) 
    
#-------- -agent 4
for k in range (N+1): 
    g = ca.vertcat(g, ((rob_dim /2 + rob_dim/2+minDist) - (np.sqrt((X[16,k]-X[12,k])**2 + (X[17,k]-X[13,k])**2))))


OPT_variables = ca.vertcat(
    X.reshape((-1, 1)),   #MPC in Multiple Shooting predicts also states..
    U.reshape((-1, 1))
)

nlp_prob = {'f': obj, 'x': OPT_variables, 'g': g ,'p': P }
#nonlinear programming solver settings
opts = {
    'ipopt': 
    {
        'max_iter': 2000,
        'print_level': 0,
        'acceptable_tol': 1e-8,
        'acceptable_obj_change_tol': 1e-6 #acceptable change on objective function
    },
    'print_time': 0
}

solver = ca.nlpsol('solver', 'ipopt',nlp_prob,opts)

lbx = ca.DM.zeros((n_states*(N+1) + n_controls*N, 1)) 
ubx = ca.DM.zeros((n_states*(N+1) + n_controls*N, 1))

#Control actions and states lower - upper boundiries
lbx[0: n_states*(N+1): n_states] = x_lb         # X lower bound 
lbx[1: n_states*(N+1): n_states] = y_lb         # Y lower bound
lbx[2: n_states*(N+1): n_states] = v_min     # Vx lower bound
lbx[3: n_states*(N+1): n_states] = v_min     # Vy lower bound

#for follower agent
lbx[4: n_states*(N+1): n_states] = x_lb         # X lower bound 
lbx[5: n_states*(N+1): n_states] = y_lb         # Y lower bound
lbx[6: n_states*(N+1): n_states] = v_min_agent     # Vx lower bound
lbx[7: n_states*(N+1): n_states] = v_min_agent     # Vy lower bound

#for follower agent
lbx[8: n_states*(N+1): n_states] = x_lb         # X lower bound 
lbx[9: n_states*(N+1): n_states] = y_lb         # Y lower bound
lbx[10: n_states*(N+1): n_states] = v_min_agent     # Vx lower bound
lbx[11: n_states*(N+1): n_states] = v_min_agent    # Vy lower bound

#for follower agent
lbx[12: n_states*(N+1): n_states] = x_lb         # X lower bound 
lbx[13: n_states*(N+1): n_states] = y_lb         # Y lower bound
lbx[14: n_states*(N+1): n_states] = v_min_agent     # Vx lower bound
lbx[15: n_states*(N+1): n_states] = v_min_agent    # Vy lower bound

#for follower agent
lbx[16: n_states*(N+1): n_states] = x_lb         # X lower bound 
lbx[17: n_states*(N+1): n_states] = y_lb         # Y lower bound
lbx[18: n_states*(N+1): n_states] = v_min_agent     # Vx lower bound
lbx[19: n_states*(N+1): n_states] = v_min_agent    # Vy lower bound

#-----------ub------------------

ubx[0: n_states*(N+1): n_states] = x_ub         # X lower bound 
ubx[1: n_states*(N+1): n_states] = y_ub         # Y lower bound
ubx[2: n_states*(N+1): n_states] = v_max     # Vx lower bound
ubx[3: n_states*(N+1): n_states] = v_max    # Vy lower bound

#for follower agent
ubx[4: n_states*(N+1): n_states] = x_ub         # X lower bound 
ubx[5: n_states*(N+1): n_states] = y_ub         # Y lower bound
ubx[6: n_states*(N+1): n_states] = v_max_agent     # Vx lower bound
ubx[7: n_states*(N+1): n_states] = v_max_agent     # Vy lower bound

#for follower agent
ubx[8: n_states*(N+1): n_states] = x_ub         # X lower bound 
ubx[9: n_states*(N+1): n_states] = y_ub         # Y lower bound
ubx[10: n_states*(N+1): n_states] = v_max_agent     # Vx lower bound
ubx[11: n_states*(N+1): n_states] = v_max_agent     # Vy lower bound

#for follower agent
ubx[12: n_states*(N+1): n_states] = x_ub         # X lower bound 
ubx[13: n_states*(N+1): n_states] = y_ub         # Y lower bound
ubx[14: n_states*(N+1): n_states] = v_max_agent     # Vx lower bound
ubx[15: n_states*(N+1): n_states] = v_max_agent     # Vy lower bound

#for follower agent
ubx[16: n_states*(N+1): n_states] = x_ub         # X lower bound 
ubx[17: n_states*(N+1): n_states] = y_ub         # Y lower bound
ubx[18: n_states*(N+1): n_states] = v_max_agent     # Vx lower bound
ubx[19: n_states*(N+1): n_states] = v_max_agent     # Vy lower bound

#Control Side
lbx[n_states*(N+1): n_states*(N+1) + n_controls*N: n_controls] = a_x_min        # a_x lower bound 
lbx[n_states*(N+1)+1: n_states*(N+1) + n_controls*N: n_controls] = a_y_min        # a_y lower bound
 
ubx[n_states*(N+1): n_states*(N+1) + n_controls*N: n_controls] = a_x_max        # a_x lower bound 
ubx[n_states*(N+1)+1: n_states*(N+1) + n_controls*N: n_controls] = a_y_max 

#Equality constraints g by Multiple Shooting
#All prediction long  inequality constraints for obstackle.
#We created constraint matrix g and now we will give interval

lbg = ca.DM.zeros(((n_states+num_agents+(num_agents*2))*(N+1),1)) 
ubg = ca.DM.zeros(((n_states+num_agents+(num_agents*2))*(N+1),1)) 

#MPC side, between target state and control action difference.
#equality constraint should  be zero 
lbg[0: n_states*(N+1): 1] = 0
ubg[0: n_states*(N+1): 1] = 0

# #Obstacle Side, inequality constraints
lbg[n_states*(N+1):(n_states+num_agents)*(N+1) : 1] = -ca.inf
ubg[n_states*(N+1):(n_states+num_agents)*(N+1) : 1] = 0 

#Swarming algorithm inequlity constraints
lbg[(n_states+num_agents)*(N+1):(n_states+num_agents+(num_agents*2))*(N+1): 1] = -r 
ubg[(n_states+num_agents)*(N+1):(n_states+num_agents+(num_agents*2))*(N+1): 1] = 0


