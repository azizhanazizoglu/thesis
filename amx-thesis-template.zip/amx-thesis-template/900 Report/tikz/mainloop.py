#We are giving an initial  horizon for MPC -> repmat(state_init, 1, N+1) 
t0 = 0
state_init = ca.vertcat(x_init, y_init, vx_init, vy_init, x_init_2, y_init_2, vx_init_2, vy_init_2, x_init_3, y_init_3, vx_init_3, vy_init_3, x_init_4, y_init_4, vx_init_4, vy_init_4, x_init_5, y_init_5, vx_init_5, vy_init_5)        # initial state
state_target = ca.DM.zeros(n_states * N)

t = ca.DM(t0)
u_init = ca.DM.zeros((n_controls, N))  # initial control, two contorl inputs = 0
#We will create initial horizon.
X0 = ca.repmat(state_init, 1, N+1)     #Copy state_init and paste N+1 times 
mpc_iter = 0 #Counter for the loop

cat_states = DM2Arr(X0) #Store predicted states
cat_controls = DM2Arr(u_init[:, 0]) #Store predicted contrul variables
times = np.array([[0]])

if __name__ == '__main__':
    main_loop = time()  # return time in sec
     while (ca.norm_2(state_init[0:2] - state_target[0:2]) > 1) and (mpc_iter < sim_time / T):
        t1 = time()
        #For initial values, we putting inital state and target state to p
        args['p'] = ca.vertcat(  
            state_init,    # current state, update in every iteretaion (k)
            #In single shooting or offline control always predictions base on
            #one intital state.Because of only one shooting
            #all obstackles location must be known in single shtooting by leader agent.
            #but in multiple shooting we are receiving update of states in every iteration.
            #It is meaning that we have new state to start in every shooting time.
            #in every time step
            state_target   # target state same always
        )
        
        args['x0'] = ca.vertcat(
            ca.reshape(X0, n_states*(N+1), 1),
            ca.reshape(u_init, n_controls*N, 1)
        )
        
        sol = solver(
                    x0=args['x0'],
                    lbx=args['lbx'],
                    ubx=args['ubx'],
                    lbg=args['lbg'],
                    ubg=args['ubg'],
                    p=args['p']
                )
        
        #in this loop only change first elements of p (initial,target) then x0
        #First step we are initalizing optimization variables with zero!
        
        #Now sol have two parameters
        #sol.x -> my minimizer for the objective function (Control Variables)
            
        u = ca.reshape(sol['x'][n_states * (N + 1):], n_controls, N)
        X0 = ca.reshape(sol['x'][: n_states * (N+1)], n_states, N+1)
        #MPC tries to predict independently u and X0  exactly same as   
        #calculated by Olfati-Saber. Look for the function -> f_swarm_dot 
         
        cat_states = np.dstack(( #Stack arrays in sequence depth wise (along third axis).
            cat_states,     #old one
            DM2Arr(X0)      #new one 
        ))
           #record follower state
           #It saved horizontally
        
        #storage our used control value 2x1
        cat_controls = np.vstack(( #Stack arrays in sequence vertically (row wise).
            cat_controls,  #old one stored here
            DM2Arr(u[:, 0]) #there is only one u!
        ))
        
        #Now next step, we applied control action;
        #Recieve the next state (new current state) state_init and make prediction based on it.
        t0, state_init, u_init = shift_timestep(T, t0, X0[0:n_states], u, f_swarm_dot)
        print('X0', X0[0:n_states])
        #For checking distance between agents, should be optimal d, minimum miDist 
        #and maksimum interection distance r.
        print('ag 1 to ag 2',(np.sqrt((X0[4,0]-X0[0,0])**2 + (X0[5,0]-X0[1,0])**2)))
        print('ag 1 to ag 3',(np.sqrt((X0[8,0]-X0[0,0])**2 + (X0[9,0]-X0[1,0])**2)))
        print('ag 1 to ag 4',(np.sqrt((X0[12,0]-X0[0,0])**2 + (X0[13,0]-X0[1,0])**2)))
        print('ag 1 to ag 5',(np.sqrt((X0[16,0]-X0[0,0])**2 + (X0[17,0]-X0[1,0])**2)))
        #state init = Take the next step's (now current) states
        #u_init = New initilaziton of optimization variables.
        #t0 = next time step
        t = np.vstack((  #save vertically all time values
            t,
            t0
        ))
        X0 = ca.horzcat(
            X0[:, 1:],
            ca.reshape(X0[:, -1], -1, 1)
        )
        # xx ...
        t2 = time()
        print(mpc_iter)
        print(t2-t1) #For HW implemention 
        times = np.vstack((
            times,
            t2-t1
        ))
        mpc_iter = mpc_iter + 1
        ss_error1 = ca.norm_2(state_init[0:2] - state_target[0:2])
        print('iteration error: ', ss_error1
    main_loop_time = time()
    ss_error = ca.norm_2(state_init[0:2] - state_target[0:2])
    print('\n\n')
    print('Total time: ', main_loop_time - main_loop)
    print('avg iteration time: ', np.array(times).mean() * 1000, 'ms')
    print('final error: ', ss_error)
      
    #Draw contol actions
    draw_control_actions(cat_controls, t, save_graph, T)
    # simulate
    simulate(cat_states, cat_controls, times, T, N,
            np.array([x_init, y_init, theta_init, x_target, y_target, theta_target]),
            np.array([x_init_2, y_init_2, theta_init_2, x_target_2, y_target_2, theta_target_2]),
            np.array([x_init_3, y_init_3, theta_init_3, x_target_3, y_target_3, theta_target_3]),
            np.array([x_init_4, y_init_4, theta_init_4, x_target_4, y_target_4, theta_target_4]),
            np.array([x_init_5, y_init_5, theta_init_5, x_target_5, y_target_5, theta_target_5]),
            save_animation,obstackles,obs_x,obs_y,obs_dim,th_1,th_2,th_3,th_4,th_5,x_ref,sim_time)    
     