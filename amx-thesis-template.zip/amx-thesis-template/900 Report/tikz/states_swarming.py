#3 Agents with point mass model
num_agents = 3

#f(x,u,k)
#Agent 1
x_1=ca.SX.sym("x_1") #as a symbolic variable
y_1=ca.SX.sym("y_1") 
vx_1=ca.SX.sym("vx_1") 
vy_1=ca.SX.sym("vy_1") 
#Agent 2
x_2=ca.SX.sym("x_2") 
y_2=ca.SX.sym("y_2")
vx_2=ca.SX.sym("vx_2") 
vy_2=ca.SX.sym("vy_2") 
#Agent 3
x_3=ca.SX.sym("x_3") 
y_3=ca.SX.sym("y_3")
vx_3=ca.SX.sym("vx_3") 
vy_3=ca.SX.sym("vy_3") 

states = ca.vertcat(x_1,y_1,vx_1,vy_1,x_2,y_2,vx_2,vy_2,x_3,y_3,vx_3,vy_3)

states1 = ca.vertcat(x_1,y_1,vx_1,vy_1)
states2 = ca.vertcat(x_2,y_2,vx_2,vy_2)
states3 = ca.vertcat(x_3,y_3,vx_3,vy_3)
   
n_states = (states.numel())


#Leader acceralation // CONTROL INPUT ~Swarming 
a_x =ca.SX.sym("a_x") 
a_y =ca.SX.sym("a_y")

controls = ca.vertcat(a_x,a_y)
n_controls = controls.numel()

# init and target points changed for 3 agents
x_init = 3.5 +10  #state1
y_init = 3.5 +10  #state2
#Agent 2 
x_init_2 = 12.5
y_init_2= 14.5
#Agent3
x_init_3 = 12.5
y_init_3= 14.5

x_target = 30
y_target = 250

x_target_2 = 35
y_target_2 = 255

x_target_3 = 30
y_target_3 = 255

#For swarming states xyvv initialization and targets
vx_init = 0  #state3
vy_init =0   #state4

vx_init_2 = 0
vy_init_2 =0

vx_init_3 = 0
vy_init_3 =0

vx_init = 0
vy_init =0

vx_init_2 = 0
vy_init_2 =0

vx_init_3 = 0
vy_init_3 =0

#Inequility Constraints as h(x,u,t)
#State constraints h(x)
x_lb = -100
y_lb = -100
vx_lb = v_min
vy_lb = v_min

x_ub = 400
y_ub = 400
vx_ub = v_max
vy_ub = v_max

#Control Constraints 
a_x_max = 7
a_x_min = -7

a_y_max = a_x_max
a_y_min = a_x_min

#For all horizon (H)
U = ca.SX.sym("U", n_controls, N) #u = n_controls x N  
#Initial states (leader and agent)  and Referance State
P = ca.SX.sym("P",n_states*2) 
X = ca.SX.sym("X",n_states,N+1) #Current state and N prediction.






