#Those are symbolic variables
#MPC uses control actions on only a_i[0] and a_i[1]
#Olfati-Saber Theory will calculate the a_i[2],  a_i[3], a_i[4] and a[5].
#In multiple shooting algorithm MPC will predict also all states.

x_swarm_dot1 = ca.vertcat(v_N[0], #state vx
                          v_N[1], #state vy
                          a_i[0],
                          a_i[1])

x_swarm_dot2 = ca.vertcat(v_N[2], #state vx_2
                          v_N[3], #state vy_2
                          a_i[2],
                          a_i[3])

x_swarm_dot3 = ca.vertcat(v_N[4], #state vx_3
                          v_N[5], #state vy_3
                          a_i[4],
                          a_i[5])

x_swarm_dot = ca.vertcat(x_swarm_dot1, x_swarm_dot2, x_swarm_dot3)

#Create the function f(x,u,k) = x_dot
f_swarm_dot = ca.Function("f_swarm_dot", [states,controls],[x_swarm_dot])

#We will use this function to see the next states.
def shift_timestep(T, t0, state_init, u, f_swarm_dot): 
    f_value = f_swarm_dot(state_init, u[:, 0]) #calculate next states 
    next_state = ca.DM.full(state_init + (T * f_value))

    t0 = t0 + T
    u_init = ca.horzcat(
        u[:, 1:], #trim first entry, (because we allready used) 
        ca.reshape(u[:, -1], -1, 1) #repeat the last one
    )

    return t0, next_state, u_init


