#velocity consensus term 
cons_0 = ca.SX.zeros(2,1);
cons_0_temp = ca.SX.zeros(2,num_agents-1);

#current speed values (no disturbution) 
#Variables designed as symbolic and updated every iteration

for b in range(1,num_agents):
     z_0 = (1/eta) * (np.sqrt(1 + eta *  ca.norm_2((states[int(n_states/num_agents*b):int(n_states/num_agents*b)+2 ,0]-states[:(int(n_states/num_agents)-2),0]))**2)- 1)
     z_01 = z_0 / r_alpha 

     marker1 = (z_01>0) + (z_01<h); #if true marker = 2
     marker2 = (z_01>=h) + (z_01<=1)
     marker3 = (z_01<0)
     marker4 = (z_01>1)
    
     a_1b = ca.if_else(marker1 == 2, 1, 
              ca.if_else(marker2 == 2, 0.5 * (1 + cos(pi*((z_01-h)/(1-h)))) ,
                ca.if_else(marker3 == 1, 0 , 
                     ca.if_else(marker4 == 1, 0, error))))
     
     # cons_0_temp[:,b-1] = ro_h * (states[int(n_states/num_agents*b+2):int(n_states/num_agents*b+4) ,0]-states[2:4,0])
     cons_0_temp[:,b-1]= a_1b * (states[int(n_states/num_agents*b+2):int(n_states/num_agents*b+4) ,0]-states[2:4,0])

#Total gradient-based term in agent side 
# cons_0 = ca.vertcat((cons_0_temp[0,:]),(cons_0_temp[1,:]));
cons_0 = cons_0_temp[:,0] + cons_0_temp[:,1]+cons_0_temp[:,2] + cons_0_temp[:,3]
