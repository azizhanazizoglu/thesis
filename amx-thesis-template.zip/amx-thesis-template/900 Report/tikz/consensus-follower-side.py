#Follower side
cons_b = ca.SX.zeros(2,num_agents-1);
cons_b_temp = ca.SX.zeros(2,num_agents-1);

for j in range (1, num_agents):
    cons_b_temp[:,:] = 0 
    for b in range(1,num_agents):
        if b != j:
            z_b = (1/eta) * (np.sqrt(1 + eta *  ca.norm_2((states[int(n_states/num_agents*b):int(n_states/num_agents*b+2) ,0]-states[int(n_states/num_agents*j):int(n_states/num_agents*j + 2),0]))**2)- 1)
            #Gradient based term (leader between followers)
            z_b1 = z_b / r_alpha 
            z_b2 = z_b - d_alpha #for p
    
            marker1 = (z_b1>0) + (z_b1<h) 
            marker2 = (z_b1>=h) + (z_b1<=1)
            marker3 = (z_b1<0)
            marker4 = (z_b1>1)
        
            #ro_h inside the phi funtion (12)
            a_jb = ca.if_else(marker1 == 2, 1, 
                              ca.if_else(marker2 == 2, 0.5 * (1 + cos(pi*((z_b1-h)/(1-h)))) ,
                                         ca.if_else(marker3 == 1, 0 , 
                                                    ca.if_else(marker4 == 1, 0, error))))
         
            cons_b_temp[:,b-1] = a_jb * (states[int(n_states/num_agents*b+2):int(n_states/num_agents*b+4) ,0]-states[int(n_states/num_agents*j+2):int(n_states/num_agents*j+4) ,0])
    
    cons_b[:,j-1] = ca.vertcat( (cons_b_temp[0,0] + cons_b_temp[0,1]+cons_b_temp[0,2] + cons_b_temp[0,3]) , 
                               (cons_b_temp[1,0] + cons_b_temp[1,1]+cons_b_temp[1,2] + cons_b_temp[1,3])) 

cons_b = ca.vertcat(cons_b[:,0],cons_b[:,1],cons_b[:,2],cons_b[:,3])
cons = ca.vertcat(cons_0,cons_b)
