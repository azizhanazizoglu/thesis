#lb 
A_b = ca.SX.sym('A_b',2,num_agents-1)
A_b_temp = ca.SX.sym('A_b_temp',2,num_agents-1) 

B_b = ca.SX.sym('B_b',2,num_agents-1)
B_b_temp = ca.SX.sym('B_b_temp',2,num_agents-1)

for b in range(1,num_agents): # 5 agents
     z_b = (1/eta) * (np.sqrt(1 + eta *  ca.norm_2((states[:(int(n_states/num_agents)-2),0]-states[int(n_states/num_agents*b):int(n_states/num_agents*b)+2 ,0]))**2)- 1)
     z_b1 = z_b / r_alpha 
     z_b2 = z_b - d_alpha #for p

     marker1 = (z_b1>0) + (z_01<h); 
     marker2 = (z_b1>=h) + (z_01<=1)
     marker3 = (z_b1<0)
     marker4 = (z_b1>1)

     ro_h = ca.if_else(marker1 == 2, 1, 
              ca.if_else(marker2 == 2, 0.5 * (1 + cos(pi*((z_b1-h)/(1-h)))) ,
                ca.if_else(marker3 == 1, 0 , 
                     ca.if_else(marker4 == 1, 0, error))))
     
     sigma_1 = (z_b2+c_b) / (np.sqrt(1 + (z_b2+c_0)**2)) 
     phi = 0.5 * ((a_0+b_0) * sigma_1 + (a_0-b_0))
     
     #direction vector pointing from pj to pi speeds as state not u
     n_b1 = (states[:(int(n_states/num_agents)-2),0]-states[int(n_states/num_agents*b):int(n_states/num_agents*b)+2 ,0]) / (np.sqrt(1 + eta * ca.norm_2((states[:(int(n_states/num_agents)-2),0]-states[int(n_states/num_agents*b):int(n_states/num_agents*b)+2 ,0]))**2))

     A_b[:,b-1] = ro_h * phi * n_b1 

A_b = ca.vertcat(A_b[:,0], A_b[:,1],A_b[:,2],A_b[:,3]) #For 5 agents, for 3 agents should be A_b = ca.vertcat(A_b[:,0], A_b[:,1])
for b in range(1,num_agents):
     z_b = (1/eta) * (np.sqrt(1 + eta *  ca.norm_2((states[:(int(n_states/num_agents)-2),0]-states[int(n_states/num_agents*b):int(n_states/num_agents*b)+2 ,0]))**2)- 1)
     z_b1 = z_b / r_alpha 

     marker1 = (z_b1>0) + (z_01<h); 
     marker2 = (z_b1>=h) + (z_01<=1)
     marker3 = (z_b1<0)
     marker4 = (z_b1>1)

     a_b1 = ca.if_else(marker1 == 2, 1, 
              ca.if_else(marker2 == 2, 0.5 * (1 + cos(pi*((z_b1-h)/(1-h)))) ,
                ca.if_else(marker3 == 1, 0 , 
                     ca.if_else(marker4 == 1, 0, error))))
     
     B_b[:,b-1] = a_b1 * (states[2:4,0]-states[int(n_states/num_agents*b+2):int(n_states/num_agents*b+4) ,0])
     
B_b = ca.vertcat(B_b[:,0], B_b[:,1],B_b[:,2], B_b[:,3])
L_b = lambda_interaction * (A_b + B_b)