#Gradient based term agent follower side (Gb)
#||pj - pb|| 
# phi_alpha_b = ca.SX.sym('phi_alpha_b',2,num_agents-1) 
# phi_alpha_b_temp = ca.SX.sym('phi_alpha_b_temp',2,(num_agents-1))  #storage x and y of agents
error = 0

for j in range (1, num_agents):
    phi_alpha_b_temp[:,:] = 0 #For all relationship between followers restart it. 
    for b in range(1,num_agents):
        if b != j:
            aa = states[int(n_states/num_agents*b):int(n_states/num_agents*b+2) ,0]
            bb = states[int(n_states/num_agents*j):int(n_states/num_agents*j + 2),0]
            z_b = (1/eta) * (np.sqrt(1 + eta* ca.norm_2(aa-bb)**2)-1)
            #Gradient based term (follower between followers)
            z_b1 = z_b / r_alpha 
            z_b2 = z_b - d_alpha #for p
    
            marker1 = (z_b1>0) + (z_b1<h) 
            marker2 = (z_b1>=h) + (z_b1<=1)
            marker3 = (z_b1<0)
            marker4 = (z_b1>1)
        
            ro_h = ca.if_else(marker1 == 2, 1, 
                              ca.if_else(marker2 == 2, 0.5 * (1 + cos(pi*((z_b1-h)/(1-h)))) ,
                                         ca.if_else(marker3 == 1, 0 , 
                                                    ca.if_else(marker4 == 1, 0, error))))
         
            sigma_1 = (z_b2+c_b) / (np.sqrt(1 + (z_b2+c_b)**2))
            phi_0 = 0.5 * ((a_b+b_b) * sigma_1 + (a_b-b_b))
         
            #direction vector pointing from pj to pb
            n_jb = (states[int(n_states/num_agents*b):int(n_states/num_agents*b+2) ,0]-states[int(n_states/num_agents*j):int(n_states/num_agents*j + 2),0]) / (np.sqrt(1 + eta * ca.norm_2((states[int(n_states/num_agents*b):int(n_states/num_agents*b+2) ,0]-states[int(n_states/num_agents*j):int(n_states/num_agents*j + 2),0]))**2))
    
            phi_alpha_b_temp[:,b-1] = ro_h * phi_0 * n_jb #2xnum_agents-1 Gradient based term.
          

    phi_alpha_b[:,j-1] = ca.vertcat( (phi_alpha_b_temp[0,0] + phi_alpha_b_temp[0,1] + phi_alpha_b_temp[0,2] + phi_alpha_b_temp[0,3]) , 
                                    (phi_alpha_b_temp[1,0] + phi_alpha_b_temp[1,1]+ phi_alpha_b_temp[1,2] + phi_alpha_b_temp[1,3])) 

phi_alpha_b = ca.vertcat(phi_alpha_b[:,0],phi_alpha_b[:,1],phi_alpha_b[:,2],phi_alpha_b[:,3])
phi_alpha = ca.vertcat(phi_alpha_0,phi_alpha_b)
