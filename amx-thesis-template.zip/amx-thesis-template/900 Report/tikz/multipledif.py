	g = X[:, 0] - P[:n_states] #initial condition constraints
	obj = 0
	for k in range (N):
		st = X[:,k]
		con = U[:,k]
		obj = obj \
			+ (st - P[n_states:]).T @ Q @ (st - P[n_states:]) \
			+ con.T @ R @ con
		st_next = X[:,k+1]  #Real State
		f_value = f(st,con)
		st_next_euler = st + (T * f_value) #predicted value 
		g = ca.vertcat(g, st_next - st_next_euler) 
	
	lbx[0: n_states*(N+1): n_states] = -40          # X lower bound 
	lbx[1: n_states*(N+1): n_states] = -40         # Y lower bound
	lbx[2: n_states*(N+1): n_states] = -ca.inf     # theta lower bound
	
	ubx[0: n_states*(N+1): n_states] = 40           # X upper bound
	ubx[1: n_states*(N+1): n_states] = 40           # Y upper bound
	ubx[2: n_states*(N+1): n_states] = ca.inf      # theta upper bound
	
	#Control Side
	lbx[n_states*(N+1):(n_states*(N+1) + n_controls*N):n_controls] = v_min #(-0,6) 
	# v lower bound for all V
	lbx[(n_states*(N+1))+1:(n_states*(N+1) + n_controls*N):n_controls] = omega_min 
	#(-0,78)# omega lower bound for all V
	
	ubx[n_states*(N+1):(n_states*(N+1) + n_controls*N):n_controls] = v_max 
	# v lower bound for all V
	ubx[n_states*(N+1)+1:(n_states*(N+1) + n_controls*N):n_controls] = omega_max 
	# omega upper bound for all V
	
	#Equality constraints g by Multiple Shooting
	lbg = ca.DM.zeros((n_states*(N+1),1)) 
	ubg = ca.DM.zeros((n_states*(N+1),1)