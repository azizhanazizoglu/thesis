# -*- coding: utf-8 -*-

from time import time
import casadi as ca
import numpy as np
from casadi import sin, cos, pi
import matplotlib.pyplot as plt
from simulation_code_single import simulate, draw_control_actions


T = 0.2 #samplig time
N = 3 #prediction horizon Nx0.2
rob_dim = 0.3 

Q_x = 1
Q_y = 5
Q_theta = 0.1
R1 = 0.5
R2 = 0.05

# specs
x_init = 0 #staring coordination of x
y_init = 0 #starting coordination of y
theta_init = 0 #starting orientation of robot
x_target = 10 
y_target = 10
theta_target = 0

#control variables restriction
v_max = 0.6 #maximum lineer speed
v_min = -v_max #minimum lineer speed
omega_max = pi/4 # max angular velocity
omega_min = -omega_max #min angular velocity

sim_time = 200 #total iteration number

#shift robot to next step. (k) -> (k+1)
def shift_timestep(T, t0, state_init, u, f): #We are not guessing!, calculating.
    f_value = f(state_init, u[:, 0]) 
    next_state = ca.DM.full(state_init + (T * f_value)) #calculate next states.

    t0 = t0 + T #increment the time
    u_init = ca.horzcat(
        u[:, 1:], #trim first entry, (because we allready used) 
        ca.reshape(u[:, -1], -1, 1) #repeat the last one
    )
    #in the first step, we initalized our control variable 0,0
    #after calculating first u
    #we can initalize from last u (args['x0'] = ...
    #... ca.reshape(u0, n_controls*N, 1) )
    return t0, next_state, u_init

def DM2Arr(dm):
    return np.array(dm.full())

#States 
x=ca.SX.sym("x") #as a symbolic variable
y=ca.SX.sym("y") #as a symbolic variable
theta=ca.SX.sym("theta") #as a symbolic variable

states = ca.vertcat(x,y,theta)
n_states = states.numel() #lenght of states

#Control variables
V = ca.SX.sym("V")
omega = ca.SX.sym("omega")

controls = ca.vertcat(V,omega)
n_controls = controls.numel()

#NL State Space 
# x_dot = V * cos(teta)
# y_dot = V * sin(teta)
# teta_dot = omega(angular velocity)

# = Euler Discretization =

# x(k+1) = x(k) + delta_t * v(k)*cos(teta)
# y(k+1) = y(k) + delta_t * v(k)*sin(teta)
# teta_dot(k+1) + delta_t * omega

rhs = ca.vertcat(V*cos(theta), #state space - right hand system
       V*sin(theta),
       omega)

f = ca.Function("f", [states,controls],[rhs]) #f(states,controls) = rhs

U = ca.SX.sym("U", n_controls, N) #u = n_controls x N matrix
#optimization problem parameters 
P = ca.SX.sym("P",n_states + n_states) #initial states and Referance states

#MPC is initalized every time step, so we need provide initial state of 
#of the robot. In real time systems, we can feed the initial states as 
#distrupted states and take in to accoont to error from outside.
#MPC gives us oppurtunity to reset all initial values and constraints in 
#each time step.

X = ca.SX.sym("X",n_states,N+1) #Big X defines the actual states
# [X_0 ; X_1 ; X_2] and predicted states in each column  
#predicted states. 
#[[X_0, X_3, X_6, X_9],
# [X_1, X_4, X_7, X_10],
# [X_2, X_5, X_8, X_11]]
#So, prediction would be stored in this matrix.
#We fill up these matrices in simulation part.

# state weights matrix (Q_X, Q_Y, Q_THETA)
Q = ca.diagcat(Q_x, Q_y, Q_theta)
# controls weights matrix
R = ca.diagcat(R1, R2)


#Given P (Initial Position and target coordinates (never change))
#In here, we predict the next states 
#we will calculate next states with control varibles and current state.
#Formulation you can see in Euler Discretion.

#According to our calculation, next 3 (N) states in every +T time
X[:,0] = P[0:3] #This state will be taken from the parameters that 
#we will pass later to the optimizer.
 
for k in range(0,N): #fill all guess N=1 
    st = X[:,k] #Extract the previous state from X 
    con = U[:,k] #Extract the control from the control matrice
    f_value = f(st,con) #f(states,controls) = rhs .. V* cos(teta)..
    st_next = st + (T * f_value) #Euler Discretion
    X[:,k+1] = st_next

#In for loop basically integrating values in X matrix.
#We did initialization from our parameters and predictions from our 
#control actions 

new_prediction = ca.Function("new_prediction",[U,P],[X])  #predict N states
#Once We know the some solution for over the prediction horizon and when 
#we plugged in these matrix and this immadiately calculates for us 
#the prediction.
#In order to avoid calculate in every step, we defined a function.
#This function is actually function of function times N. 
#This is all nonlinear propagation of these control actions through our
#prediction.

#MPC Controller (Running State Controllers)
#-----------------------------------------------------------------------------
#(Online Optimization) for every step
#We want too see how we are close to our target state after prediction
#Running Cost is  l(x,u)=  (||x_u - x^r||^2) *Q  +  (||u-u^r||^2) *R
#Here in every step, we are looking for how we close to target
#So Objective function is summ of the all running costs 
#and how much consuming energy, we can penalize with Q and R
#u_r = 0, u = current 
#x_r = target, at least same for N iteration (Here completly)

#-----------------------------------------------------------------------------
#Now like Optimal Control NLP solver, but we have objective function from MPC
obj = 0

# #objective Function
for i in range (N):
    st = X[:,i]
    # print(i)
    con = U[:,i]
    obj = obj \
        + (st - P[n_states:]).T @ Q @ (st - P[n_states:]) \
        + con.T @ R @ con


# #compute constraints
# g = [n_states][N+1]
g = ca.SX.sym("g", n_controls, N+1)


for i in range(N+1): #box constraints due to the map margins.
    g[0,i] = X[0,i] #state x
    g[1,i] = X[1,i] #state y
    #In further those values shouldnt achieve map constraints
 #As we talked about in formula 3.18 we must respect to inequality constraints
 
 #As equality constraints, 
 #MPC tries to guess same states as real states of the system.
    
g= g.reshape((-1,1))

OPT_variables = U.reshape((-1,1))
#u_0, u_1 (v,w)  u_2,u_3  u_4,u5

nlp_prob = {'f': obj, 'x': OPT_variables, 'g': g ,'p': P }
#NLP structure
#which has objective and calculted already
#Optimization variables which should be one vector
#constraints as g
#and P for initilizig states and target states

opts = {
    'ipopt': 
    {
        'max_iter': 1000,
        'print_level': 0,
        'acceptable_tol': 1e-8,
        'acceptable_obj_change_tol': 1e-6 #acceptable change on 
        #objective function
    },
    'print_time': 0
}

solver = ca.nlpsol('solver', 'ipopt',nlp_prob,opts)

#Optimization Variables constraints!
lbx = ca.DM.zeros((OPT_variables.numel(),1))
ubx = ca.DM.zeros((OPT_variables.numel(),1)) #zero matrix
#Constraints for control actions
for i in range(OPT_variables.numel()):
    if(i % 2) == 0:
        lbx[i] = v_min 
        ubx[i] = v_max
    else:
        lbx[i] = omega_min
        ubx[i] = omega_max
# print(lbx)

#State Constraints
#We have upper and lower boundries on g. 
# g was the x and y position of the robot over the whole prediction  horizon
lbg = -14 #lower boundry of states
ubg = 14 #upper boundry of states 

args ={
       'lbx': lbx, 
       'ubx': ubx, 
       
       'lbg': lbg, 
       'ubg': ubg, 
       
       # 'p':[], #There is no parameters in this optimization problem
       # 'x0' #Initilization of the optimization variable
       #           
       } 

#all of the above is just a problem setting up
#-----------------------------------------------------------------------------

#-----------------------------------------------------------------------------
#The Simulation Loop Should Start From here

t0 = 0
state_init = ca.DM([x_init, y_init, theta_init])        # initial state
state_target = ca.DM([x_target, y_target, theta_target])  # target state

#DM is mainly used for storing matrices in CasADi
xx = ca.DM(state_init) #xx will contain the history of state
t = ca.DM(t0)

u_init = ca.DM.zeros((n_controls, N))  # initial control, two contorl inputs
X0 = ca.repmat(state_init, 1, N+1)         # initial state 

#Start MPC

mpc_iter = 0 #Counter for the loop 
cat_states = DM2Arr(X0) #Store predicted states
cat_controls = DM2Arr(u_init[:, 0]) #Store predicted contrul variables
times = np.array([[0]])

#Main Loop
# the main simulaton loop... it works as long as the error is greater
# than 0.5 and the number of mpc steps is less than its maximum
# value.

if __name__ == '__main__':
    main_loop = time()  # return time in sec
    while (ca.norm_2(state_init-state_target) > 0.5) and(mpc_iter<sim_time/T):
        t1 = time()
        #For initial values, we putting inital state and target state to p
        #In this loop only args['p']
        args['p'] = ca.vertcat(  
            state_init,    # current state, will change in every iteration
            state_target   # target state, will change incase of trajectory
            #following
        )
        # print(args["p"][0:3])

        # optimization variable current state (for initializing)
        # we can also initialize x0 different in every time step..
        # going to have look in MULTIPLE SHOOTING technique.
        args['x0'] = ca.reshape(u_init, n_controls*N, 1) 
        #Included all predictions.
        

        sol = solver(
            x0=args['x0'],
            lbx=args['lbx'],
            ubx=args['ubx'],
            lbg=args['lbg'],
            ubg=args['ubg'],
            p=args['p']
        )
        
        #in this loop only change first p (initial,target) then x0
        #Every time step,  the initial, current (state_init) will change
        #state target remains same.
        #First step we are initalizing optimization variables with zero!
        
        #Now sol have two parameters
        #sol.x -> my minimizer for the object function ( Control Variables)
        #Optimal Control Variables as u
        u = ca.reshape(sol['x'], n_controls, N)
        
        #Compute Optimal solution trajectory
        #We know the calculated control actions and now 
        #we want the predict the states with function of new_prediction
        new_prediction_value =new_prediction(u,args["p"])
        #We will recieve X values for N horizon.
       
        cat_states = np.dstack(( #Stack arrays in sequence depth wise (along third axis).
            cat_states,     #old one
            DM2Arr(new_prediction_value)      #new one 
        ))
        #It saved horizontally
        
        #storage our used control value 2x1
        cat_controls = np.vstack(( #Stack arrays in sequence vertically (row wise).
            cat_controls,  #old one stored here
            DM2Arr(u[:, 0]) #new one
        ))
        #storage all u (predicted and currently), predicted = will used next step
        #It saved vertically
        # print(cat_controls) 
        
        t = np.vstack((  #save vertically all time values
            t,
            t0
        ))
        
        #Now next step, we applied control action;
        #This is not prediction, this is real state!
        t0, state_init, u_init = shift_timestep(T, t0, args["p"][0:3], u, f)
        #state init = Take the next step's (now current) states
        #u_init = New initilaziton of optimization variables.
        #We did zero in the beginning now we are starting from calcuilated 
        #control actions
        #t0 = next time step
    
        X0 = ca.horzcat(
            u[:, 1:],
            ca.reshape(u[:, -1], -1, 1)
        )

        t2 = time()
        print(mpc_iter)
        print(t2-t1)
        times = np.vstack((
            times,
            t2-t1
        ))
        
        mpc_iter = mpc_iter + 1
        ss_error1 = ca.norm_2(state_init - state_target)
        print('iteration error: ', ss_error1)
        
    main_loop_time = time()
        
    ss_error = ca.norm_2(state_init - state_target)
        
    print('\n\n')
    print('Total time: ', main_loop_time - main_loop)
    print('avg iteration time: ', np.array(times).mean() * 1000, 'ms')
    print('final error: ', ss_error)
        
     # Visualazation.
   
    simulate(cat_states, cat_controls, times, T, N,
             np.array([x_init, y_init, theta_init, x_target, y_target, theta_target]), save=True)    
        
    #Draw contol actions
    draw_control_actions(cat_controls, t)

    








