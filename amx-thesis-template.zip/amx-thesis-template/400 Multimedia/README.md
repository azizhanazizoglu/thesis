`400 Multimedia` store thesis-relevant photos or videos here

It is strongly recommended you unversion this folder
