`050 Procurement` store all information about purchases or external services here
