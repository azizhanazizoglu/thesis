`800 Third-party software` use this folder for third-party toolboxes or other software

It is strongly recommended you unversion this folder
