`032 Final presentation` folder for the final presentation slides (applicable only for bachelor's or for master's thesis)
