# Thesis template
We have prepared a template for you, which contains a practical folder structure for your project and a LaTeX document template.

:warning: Please _do not distribute_ this repo nor make it public in _any_ way.

## How to use the folder structure
The folders are named using the decimal classification:
* `000 Admin` put all administrative stuff here, like registration forms, declarations etc.
* `010 Project management` here are all your planning documents, i.e. timetables, Gantt charts etc.
* `020 Meetings` store meeting protocols here
* `030 Presentations` if you prepare some intermediate presentations (optional), store your slides here
* `031 Expose` here is your expose presentation, i.e. objectives, detailed task description, planned research methods and project planning
* `032 Final presentation` folder for the final presentation slides (applicable only for bachelor's or for master's thesis)
* `040 Task description` place your thesis' task description here
* `050 Procurement` store all information about purchases or external services here
* `060 Emails` place the relevant emails here
* `100 Design and models` this folder is for models or CAD data
* `200 Code` here are all your programs
* `300 Experiments` here is the description of your experiments and measurement results
* `400 Multimedia` store thesis-relevant photos or videos here
* `800 Third-party software` use this folder for third-party toolboxes or other software
* `900 Report` the LaTeX project is in this folder
* `910 Literature` store papers and books here

## Versioning rules
By convention, all PDFs that start with an underscore are considered secondary data and are not versioned.

## How to use the LaTeX template
* Get [MiKTeX](http://miktex.org/download)
* Get [TeXstudio](http://www.texstudio.org/)
* Get [JabRef](http://www.jabref.org/#downloads)
* Get [TikzEdt](http://www.tikzedt.org/)

### `expl3` error
If you get the following error:

```
Package siunitx error: support package **expl3** too old
```

when compiling the LaTeX report, then you should:
* Go to `Start/Programs/MiKTeX 2.9/Maintenance (Admin)` and open `MiKTeX Update (Admin)`
* Update all MiKTeX packages (you may need two passes to update the core first)
* Go to `Start/Programs/MiKTeX 2.9/Maintenance (Admin)` and open `MiKTeX Package Manager (Admin)`
* Uninstall and then install the `l3kernel` package


## Tools
Good tools are important for your workflow. Here are some recommended programs:
* Text editors:
    * [Atom](https://atom.io/) (also install packages `platformio-ide-terminal`, `zen`, `scroll-sync`, `language-latex`, `language-matlab-octave`)
    * [Notepad++](https://notepad-plus-plus.org/)
* Git clients:
    * [SmartGit](http://www.syntevo.com/smartgit/) (great functionality, ideal for power users)
    * [SourceTree](https://www.sourcetreeapp.com/)
    * [GitHub Desktop](https://desktop.github.com/) (nice and simple interface, less low-level control, ideal for beginners)

Good luck and have fun! :rocket:
