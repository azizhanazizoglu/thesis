# Making changes
You are welcome to improve and update our template. Please make changes in your own branch (`dev-...`) and open a pull request. `master` branch should contain no work in progress!

# Checklist: Before you commit
## Linefeeds at the end of file
All text files should have a linefeed (`\n`) at the end of file.

## Whitespaces
Please strip all trailing whitespaces before commiting text files. Since git diff is sensitive to whitespaces, this will prevent excessive whitespace-only changes.

## Tabs
Please do not use hard tabs! Use only soft-tabs with 4 whitespaces.
